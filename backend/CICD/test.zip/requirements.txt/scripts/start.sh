#!/bin/bash
set -e
cd /home/ec2-user/app/backend
source venv/bin/activate
nohup uvicorn main:app --host 0.0.0.0 --port 8000 > /var/log/fastapi.log 2>&1 &
