#!/bin/bash
pkill -f "uvicorn" || true
