#!/bin/bash
set -e
cd /home/ec2-user/app/backend

if ! command -v python3 &> /dev/null; then
    sudo dnf install -y python3
fi
python3 -m venv venv
source venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt
echo "FastAPI dependencies installed successfully"
