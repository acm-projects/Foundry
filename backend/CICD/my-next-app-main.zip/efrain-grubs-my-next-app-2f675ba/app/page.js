import Image from "next/image";

export default function Home() {
  return (
   <div> 


hello world!
please work
    </div>
  );
}
